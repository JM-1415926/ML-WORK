* Linear_regression.py: Added copy_X and fit_intercept parameters at line 50, their roles are:
	1. copy_X: If True, a copy of the input data X will be made. Otherwise, the original data may be overwritten
	2. fit_intercept: If True, the model will calculate an intercept term.

* decision_tree.py: Added max_depth, min_samples_split, and random_state parameters at line 23 to limit the size of the tree. Now the code can visualize the generated tree, so I uncommented the relevant section :)
	1. max_depth: Limits the maximum depth of the tree to prevent overfitting.
	2. min_samples_split: Controls the minimum number of samples required to split an internal node.
	3. random_state: Sets the random seed.

* SVM.py: Added kernel, C, and epsilon parameters at line 21, their roles are:
	1. kernel: Specifies the type of kernel function used in the model.
	2. C: Regularization parameter that controls the model's tolerance to errors.When C=1, it balances the trade-off between achieving a low training error and maintaining 	model simplicity.
	3. epsilon: Defines the epsilon-insensitive region where errors within this range are not penalized, affecting the model's precision and tolerance to noise.
